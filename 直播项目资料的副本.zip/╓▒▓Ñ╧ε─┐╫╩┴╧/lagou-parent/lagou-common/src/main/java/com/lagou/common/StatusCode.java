package com.lagou.common;

/**
 * 返回码
 */
public class StatusCode {

    public static final int OK = 20000;//成功
    public static final int ERROR = 20001;//失败

    public static final int RED_PACKET_IS_OPEN = 20002;//红包已打开

    public static final int RED_PACKET_END = 20003;//红包已结束
}
