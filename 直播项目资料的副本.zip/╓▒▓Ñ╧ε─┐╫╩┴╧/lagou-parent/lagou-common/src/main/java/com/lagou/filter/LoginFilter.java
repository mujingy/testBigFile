package com.lagou.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@Component
public class LoginFilter implements Filter {


    public static final String[] excludesUrl = new String[]{"/toLogin", "/login",
            "register", "/toRegister", "/css/", "/img/", "/js/"};

    @Value("${chatServer}")
    public String chatServer;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String requestURI = request.getRequestURI();

        boolean isExcludeUrl = false;

        for (String excludeUrl : excludesUrl) {
            //1.包含指定字符串放行
            if (requestURI.contains(excludeUrl)) {
                isExcludeUrl = true;
                break;
            }
        }
        if (isExcludeUrl) {
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        } else {
            HttpSession session = request.getSession();
            Object user = session.getAttribute("user");
            if (user != null) {
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }

            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();//通过servlet的doget方法获取response对象，通过getWriter方法获取PrintWriter对象
            out.flush();//清空缓存
            out.println("<script>");//输出script标签
            out.println("alert('您还没有登录，请前往登录！');");//js语句：输出alert语句
            out.println("location.href='http://" + chatServer + ":8081/user/toLogin';");//js语句：输出网页回退语句
            out.println("</script>");//输出script结尾标签
        }

    }

    @Override
    public void destroy() {

    }

}
