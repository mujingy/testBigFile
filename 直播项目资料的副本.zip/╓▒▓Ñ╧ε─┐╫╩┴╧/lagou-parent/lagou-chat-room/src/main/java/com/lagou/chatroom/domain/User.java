package com.lagou.chatroom.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * 用户实体类
 */
@TableName("t_user")
@Data
public class User implements Serializable {

    @TableId
    private Long id;
    @TableField
    private String username;
    @TableField
    private String nickname;
    @TableField
    private String password;
    @TableField
    private Date createdDate;
}
