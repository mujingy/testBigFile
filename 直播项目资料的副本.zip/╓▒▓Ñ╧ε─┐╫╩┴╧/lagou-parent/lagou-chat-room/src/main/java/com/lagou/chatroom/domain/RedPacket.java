package com.lagou.chatroom.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 红包信息
 */
@Data
@TableName("t_red_packet")
public class RedPacket implements Serializable {
    /**
     * 红包ID
     */
    @TableId
    private Long id;
    /**
     * 红包金额
     */
    @TableField
    private Double amount;
    /**
     * 红包个数
     */
    @TableField
    private Integer num;
    /**
     * 剩余红包金额
     */
    @TableField
    private Double remainingAmount;
    /**
     * 剩余红包个数
     */
    @TableField
    private Integer remainingNum;
    /**
     * 用户id
     */
    @TableField
    private Long userId;

    /**
     * 用户姓名
     */
    @TableField
    private String username;
    /**
     * 创建时间
     */
    @TableField
    private Date createTime;

}
