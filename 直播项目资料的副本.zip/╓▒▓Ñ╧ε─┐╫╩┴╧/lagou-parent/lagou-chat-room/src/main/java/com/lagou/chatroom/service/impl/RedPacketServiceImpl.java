package com.lagou.chatroom.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lagou.chatroom.config.RabbitConfig;
import com.lagou.chatroom.domain.RedPacket;
import com.lagou.chatroom.domain.RedPacketRecord;
import com.lagou.chatroom.mapper.RedPacketMapper;
import com.lagou.chatroom.service.RedPacketService;
import com.lagou.chatroom.service.UserAccountService;
import com.lagou.chatroom.utils.RedisLockUtils;
import com.lagou.common.ResponseResult;
import com.lagou.common.StatusCode;
import com.lagou.utils.IdWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class RedPacketServiceImpl extends ServiceImpl<RedPacketMapper, RedPacket>
        implements RedPacketService {


    public static final String RED_PACKET_RECORD_KEY = "_record_key";

    public static final String RED_PACKET_KEY = "_packet_key";

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    UserAccountService userAccountService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    IdWorker idWorker;

    @Override
    public ResponseResult addPacket(Long userId, String username, Double amount, Integer num) {
        //1.红包参数检查
        if (amount == null || num == null) {
            return new ResponseResult(false, StatusCode.ERROR, "金额或个数不能为空");
        }
        if (amount <= 0 || num <= 0) {
            return new ResponseResult(false, StatusCode.ERROR, "金额或个数值不能为0");
        }
        double avg = amount / num;
        if (avg <= 0.01) {
            return new ResponseResult(false, StatusCode.ERROR, "红包平均金额必须大于0.01");
        }

        //2.检查账户额度是否可以发红包
        ResponseResult responseResult = userAccountService.checkAmount(userId, amount);
        if (responseResult.isFlag()) {
            //3.创建红包
            RedPacket redPacket = new RedPacket();
            redPacket.setUserId(userId);
            redPacket.setUsername(username);
            redPacket.setAmount(amount);
            redPacket.setNum(num);
            redPacket.setRemainingAmount(amount);
            redPacket.setRemainingNum(num);
            redPacket.setCreateTime(new Date());
            Long redPacketId = idWorker.nextId();
            redPacket.setId(redPacketId);
            //4.保存红包
            this.save(redPacket);
            //5.往redis插入红包
            redisTemplate.boundValueOps(redPacketId + RED_PACKET_KEY).set(redPacket, 1, TimeUnit.DAYS);
            //6.扣减账户额度
            userAccountService.transaction(userId, -amount, 1, "发送红包");
            return new ResponseResult(true, StatusCode.OK, "发送红包成功", redPacketId + "");
        }
        return responseResult;
    }

    /**
     * 抢红包
     *
     * @param redPacketId
     * @return
     */
    @Override
    public ResponseResult getRedPacket(Long redPacketId, Long userId) {
        //1.从缓存中读取红包个数
        RedPacket redPacket = (RedPacket) redisTemplate.boundValueOps(redPacketId + RED_PACKET_KEY).get();
        //2.获取红包记录
        Map<Object, RedPacketRecord> entries = redisTemplate.opsForHash().entries(redPacketId + RED_PACKET_RECORD_KEY);
        List list = new ArrayList();
        //3.判断使用是否抢过红包
        boolean isOpen = this.userIsOpen(userId, list, entries);
        //4.判断是否还有红包
        if (redPacket != null && redPacket.getRemainingNum() > 0) {
            //5.判断是否已抢过
            if (isOpen) {
                return new ResponseResult(false, StatusCode.RED_PACKET_IS_OPEN, "已抢过红包!|"
                        + redPacket.getAmount() + "|" + redPacket.getNum() + "|" + redPacket.getUsername(), list);
            }
            return new ResponseResult(true, StatusCode.OK, "抢到红包!", redPacket);
        } else {
            //从数据库中查询红包信息返回
            redPacket = this.getById(redPacketId);
            return new ResponseResult(false, StatusCode.RED_PACKET_IS_OPEN, "红包已抢完!|"
                    + redPacket.getAmount() + "|" + redPacket.getNum() + "|" + redPacket.getUsername(), list);
        }
    }

    /**
     * 开红包
     *
     * @param redPacketId
     * @return
     */
    @Override
    public ResponseResult openRedPacket(Long redPacketId, Long userId, String username) {
        String lockId = "";
        //ZookeeperLockUtils distributedLock = null;
        try {
            //distributedLock = new ZookeeperLockUtils();
            //distributedLock.acquireLock();

            //redis分布式锁
            lockId = RedisLockUtils.lockFailThrowException(redisTemplate, "openRedPacket", 10);
            //1.从缓存中读取红包
            RedPacket redPacket = (RedPacket) redisTemplate.boundValueOps(redPacketId + RED_PACKET_KEY).get();
            //2.从缓存中读取红包记录
            Map<Object, RedPacketRecord> entries = redisTemplate.opsForHash().entries(redPacketId + RED_PACKET_RECORD_KEY);
            List list = new ArrayList();
            //3.判断是否还有红包
            if (redPacket != null && redPacket.getRemainingNum() > 0) {
                //4.判断用户是否已经抢过红包
                if (this.userIsOpen(userId, list, entries)) {
                    return new ResponseResult(false, StatusCode.RED_PACKET_IS_OPEN, "已抢过红包!|"
                            + redPacket.getAmount() + "|" + redPacket.getNum() + "|" + redPacket.getUsername(), list);
                }
                //5.获取随机红包金额
                Double randomAmount = getRandomMoney(redPacket);
                log.info("抢到的红包金额为:" + randomAmount);
                //6.修改redis
                if (redPacket.getRemainingNum() == 0) {
                    redisTemplate.delete(redPacketId + RED_PACKET_KEY);
                    log.info("红包已经抢完,删除redis红包记录");
                } else {
                    redisTemplate.boundValueOps(redPacketId + RED_PACKET_KEY).set(redPacket);
                }
                //7.添加红包记录到redis缓存
                RedPacketRecord redPacketRecord = new RedPacketRecord();
                redPacketRecord.setId(idWorker.nextId());
                redPacketRecord.setUserId(userId);
                redPacketRecord.setUsername(username);
                redPacketRecord.setRedPacketId(redPacketId);
                redPacketRecord.setCreateTime(new Date());
                redPacketRecord.setAmount(randomAmount);
                if (entries != null) {
                    entries.put(redPacketRecord.getId(), redPacketRecord);
                } else {
                    entries = new HashMap<>();
                    entries.put(redPacketRecord.getId(), redPacketRecord);
                }
                list.add(redPacketRecord);
                //8.发送MQ异步解耦-红包记录入库及账户金额修改
                rabbitTemplate.convertAndSend(RabbitConfig.RED_PACKET_EXCHANGE,
                        RabbitConfig.RECORD_ROUTING_KEY, redPacketRecord,
                        new CorrelationData(redPacketRecord.getRedPacketId().toString()));

                //9.将红包记录更新缓存
                redisTemplate.opsForHash().putAll(redPacketId + RED_PACKET_RECORD_KEY,
                        entries);
                return new ResponseResult(true, StatusCode.OK, "抢到红包", list);
            } else {
                //将map转化list
                for (RedPacketRecord record : entries.values()) {
                    list.add(record);
                }
                return new ResponseResult(false, StatusCode.ERROR, "红包已抢完", list);
            }

        } finally {
            //distributedLock.releaseLock();
            RedisLockUtils.unlock(redisTemplate, "openRedPacket", lockId);
        }
    }

    /**
     * 判断用户是否抢过红包
     *
     * @param userId
     * @param list
     * @param entries
     * @return
     */
    public boolean userIsOpen(Long userId, List list, Map<Object, RedPacketRecord> entries) {
        if (entries == null) {
            return false;
        }
        boolean isOpen = false;
        for (RedPacketRecord record : entries.values()) {
            list.add(record);
            if (record.getUserId().longValue() == userId.longValue()) {
                isOpen = true;
            }
        }
        return isOpen;
    }


    public static double getRandomMoney(RedPacket redPacket) {
        // 剩余的红包数量
        Integer remainingNum = redPacket.getRemainingNum();
        // 剩余的金额
        Double remainingAmount = redPacket.getRemainingAmount();
        if (remainingNum == 1) {
            redPacket.setRemainingNum(--remainingNum);
            redPacket.setRemainingAmount(0d);
            return (double) Math.round(remainingAmount * 100) / 100;
        }
        Random r = new Random();
        //最小金额
        double min = 0.01;
        //最大金额
        double max = remainingAmount / remainingNum * 2;
        //获取随机金额
        double money = r.nextDouble() * max;
        money = money <= min ? 0.01 : money;
        money = Math.floor(money * 100) / 100;

        //设置剩余金额
        remainingAmount -= money;
        redPacket.setRemainingAmount(remainingAmount);
        //设置剩余红包个数
        redPacket.setRemainingNum(--remainingNum);
        return money;
    }
}
