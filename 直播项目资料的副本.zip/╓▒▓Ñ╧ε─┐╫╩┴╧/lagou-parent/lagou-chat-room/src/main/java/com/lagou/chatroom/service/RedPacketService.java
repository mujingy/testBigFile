package com.lagou.chatroom.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.lagou.chatroom.domain.RedPacket;
import com.lagou.common.ResponseResult;

public interface RedPacketService extends IService<RedPacket> {

    ResponseResult addPacket(Long userId, String username, Double amount, Integer num);

    ResponseResult getRedPacket(Long redPacketId, Long userId);

    ResponseResult openRedPacket(Long redPacketId, Long userId, String username);
}
