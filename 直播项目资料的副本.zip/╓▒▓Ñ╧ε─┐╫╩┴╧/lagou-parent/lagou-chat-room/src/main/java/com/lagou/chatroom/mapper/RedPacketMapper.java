package com.lagou.chatroom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.chatroom.domain.RedPacket;

public interface RedPacketMapper extends BaseMapper<RedPacket> {
}
