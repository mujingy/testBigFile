package com.lagou.chatroom;

import com.lagou.chatroom.common.SpringUtil;
import com.lagou.chatroom.netty.NettyWebsocketServer;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.lagou.chatroom.event.EventRegist;
import com.lagou.chatroom.handler.Handler;
import com.lagou.chatroom.handler.HandlerRegist;

@SpringBootApplication(scanBasePackages = "com.lagou")
@MapperScan(basePackages = {"com.lagou.chatroom.mapper"}) // mybatis包扫描
public class NettyChatRoomApplication implements CommandLineRunner {


    @Autowired
    private NettyWebsocketServer nettyWebsocketServer;

    public static void main(String[] args) throws Exception {
        ApplicationContext app = SpringApplication.run(NettyChatRoomApplication.class, args);
        SpringUtil.context = app;
        /** 注册消息处理 */
        String[] names = SpringUtil.context.getBeanNamesForType(Handler.class);
        for (String name : names) {
            Object object = SpringUtil.context.getBean(name);
            if (Handler.class.isInstance(object)) {
                HandlerRegist.regist((Handler) object);
                EventRegist.regist((Handler) object);
            }
        }
    }

    @Override
    public void run(String... args) throws Exception {
        /** 启动netty websocket服务器 */
        new Thread(nettyWebsocketServer).start();
    }

}

