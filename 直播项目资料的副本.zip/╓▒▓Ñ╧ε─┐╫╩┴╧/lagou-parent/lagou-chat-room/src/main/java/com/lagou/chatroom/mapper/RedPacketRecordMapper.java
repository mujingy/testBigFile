package com.lagou.chatroom.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.chatroom.domain.RedPacketRecord;

public interface RedPacketRecordMapper extends BaseMapper<RedPacketRecord> {
}
