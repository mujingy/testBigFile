package com.lagou.chatroom.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lagou.chatroom.domain.User;
import com.lagou.chatroom.mapper.UserMapper;
import com.lagou.chatroom.service.UserAccountService;
import com.lagou.chatroom.service.UserService;
import com.lagou.utils.IdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
        implements UserService {

    @Autowired
    IdWorker idWorker;

    @Autowired
    UserAccountService userAccountService;

    @Override
    public boolean register(User user) {
        //1.根据用户名查询用户是否存在
        if (getByUsername(user.getUsername()) == null) {
            user.setId(idWorker.nextId());
            user.setCreatedDate(new Date());
            //2.保存用户
            this.save(user);
            //3.调用账户中心设置初始账户
            userAccountService.addAmount(user.getId(), 0d, 1);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public User getByUsernameAndPassword(String username, String password) {
        QueryWrapper<User> queryWrapper = new QueryWrapper();
        queryWrapper.lambda().eq(User::getUsername, username);
        queryWrapper.lambda().eq(User::getPassword, password);
        return this.getOne(queryWrapper);
    }


    /**
     * 根据用户名查询用户
     *
     * @param username
     * @return
     */
    public User getByUsername(String username) {
        QueryWrapper<User> queryWrapper = new QueryWrapper();
        queryWrapper.lambda().eq(User::getUsername, username);
        return this.getOne(queryWrapper);
    }
}
