package com.lagou.chatroom.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lagou.chatroom.domain.RedPacketRecord;


public interface RedPacketRecordService extends IService<RedPacketRecord> {
}
