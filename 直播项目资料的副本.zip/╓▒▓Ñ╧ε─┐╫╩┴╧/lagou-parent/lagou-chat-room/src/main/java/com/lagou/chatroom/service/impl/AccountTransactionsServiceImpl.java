package com.lagou.chatroom.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lagou.chatroom.domain.AccountTransactions;
import com.lagou.chatroom.mapper.AccountTransactionsMapper;
import com.lagou.chatroom.service.AccountTransactionsService;
import org.springframework.stereotype.Service;

@Service
public class AccountTransactionsServiceImpl extends ServiceImpl<AccountTransactionsMapper, AccountTransactions>
        implements AccountTransactionsService {
}
