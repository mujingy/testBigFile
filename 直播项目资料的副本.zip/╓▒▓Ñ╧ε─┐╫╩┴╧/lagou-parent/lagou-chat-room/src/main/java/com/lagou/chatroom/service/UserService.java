package com.lagou.chatroom.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lagou.chatroom.domain.User;

public interface UserService extends IService<User> {
    boolean register(User user);

    User getByUsernameAndPassword(String username, String password);

    User getByUsername(String username);
}
