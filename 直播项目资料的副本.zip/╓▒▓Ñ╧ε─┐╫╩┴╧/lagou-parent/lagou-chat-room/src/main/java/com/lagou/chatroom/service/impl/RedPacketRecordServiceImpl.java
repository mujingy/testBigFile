package com.lagou.chatroom.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lagou.chatroom.domain.RedPacketRecord;
import com.lagou.chatroom.mapper.RedPacketRecordMapper;
import com.lagou.chatroom.service.RedPacketRecordService;
import org.springframework.stereotype.Service;

@Service
public class RedPacketRecordServiceImpl extends ServiceImpl<RedPacketRecordMapper, RedPacketRecord>
        implements RedPacketRecordService {
}
