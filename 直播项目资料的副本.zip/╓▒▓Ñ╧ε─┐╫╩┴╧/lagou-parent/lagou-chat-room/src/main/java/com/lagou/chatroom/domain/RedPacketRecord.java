package com.lagou.chatroom.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 抢红包记录
 */
@Data
@TableName("t_red_packet_record")
public class RedPacketRecord implements Serializable {

    /**
     * 红包记录Id
     */
    @TableId
    private Long id;
    /**
     * 抢到红包的金额
     */
    @TableField
    private Double amount;
    /**
     * 抢到红包的用户名
     */
    @TableField
    private String username;

    /**
     * 抢到红包用户的用户Id
     */
    @TableField
    private Long userId;
    /**
     * 红包id
     */
    @TableField
    private Long redPacketId;
    /**
     * 创建时间
     */
    @TableField
    private Date createTime;

}
