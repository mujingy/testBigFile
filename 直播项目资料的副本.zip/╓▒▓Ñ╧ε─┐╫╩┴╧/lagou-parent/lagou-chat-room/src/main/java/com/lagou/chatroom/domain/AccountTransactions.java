package com.lagou.chatroom.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * 账户交易记录
 */
@Data
@TableName("t_account_transactions")
public class AccountTransactions {
    /**
     * 记录ID
     */
    @TableId
    private Long id;

    /**
     * 账户ID
     */
    @TableField
    private Long accountId;

    /**
     * 交易金额
     */
    @TableField
    private Double transactionAmount;

    /**
     * 交易类型
     */
    @TableField
    private Integer transactionType;

    /**
     * 交易描述
     */
    @TableField
    private String transactionDescription;

    /**
     * 交易时间
     */
    @TableField
    private Date transactionTime;

}
