package com.lagou.chatroom.controller;

import com.alibaba.fastjson.JSON;
import com.lagou.chatroom.domain.User;
import com.lagou.chatroom.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Value("${chatServer}")
    public String chatServer;

    /**
     * 执行注册 成功后登录页面 否则调回注册页面
     */
    @PostMapping("/register")
    public String register(User user, HttpServletResponse response) {
        PrintWriter out = null;
        try {
            response.setContentType("text/html;charset=utf-8");
            out = response.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ;
        if (userService.register(user) == true) {
            //注册成功，重定向登录页面
            out.print("<script language=\"javascript\">alert('注册成功，欢迎使用！');</script>");

            return "login";
        } else {
            //失败重定向注册页面
            out.print("<script language=\"javascript\">alert('注册失败，用户名重复！');</script>");

            return "register";
        }
    }

    /**
     * 跳转登录页面
     *
     * @return
     */
    @RequestMapping("/toLogin")
    public String index() {
        return "login";
    }


    /**
     * 跳转注册页面
     *
     * @return
     */
    @RequestMapping("/toRegister")
    public String toRegister() {
        return "register";
    }


    @PostMapping("/login")
    public String login(User user, RedirectAttributes attr, HttpServletRequest request, HttpServletResponse response) {
        User getUser = userService.getByUsernameAndPassword(user.getUsername(), user.getPassword());
        PrintWriter out = null;
        if (getUser != null) {
            //将user对象转换json放入session中
            request.getSession().setAttribute("user", JSON.toJSONString(getUser));
            //登陆成功，重定向聊天页面
            return "redirect:http://" + chatServer + ":8081/chat";
        } else {
            try {
                response.setContentType("text/html;charset=utf-8");
                out = response.getWriter();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //失败重定向登录页面
            out.print("<script language=\"javascript\">alert('用户名或密码错误，请重试！');</script>");

            return "login";
        }
    }
}
