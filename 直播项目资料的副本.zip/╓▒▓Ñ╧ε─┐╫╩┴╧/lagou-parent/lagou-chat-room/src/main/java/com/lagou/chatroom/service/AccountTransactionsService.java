package com.lagou.chatroom.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lagou.chatroom.domain.AccountTransactions;
import org.springframework.stereotype.Service;

@Service
public interface AccountTransactionsService extends IService<AccountTransactions> {

}
