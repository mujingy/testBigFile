package com.lagou.chatroom.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lagou.chatroom.domain.UserAccount;
import com.lagou.common.ResponseResult;
import org.springframework.stereotype.Service;

@Service
public interface UserAccountService extends IService<UserAccount> {


    void transaction(Long userId, Double amount, Integer type, String description);

    ResponseResult checkAmount(Long userId, Double amount);

    void addAmount(Long userId, Double amount, Integer status);
}
