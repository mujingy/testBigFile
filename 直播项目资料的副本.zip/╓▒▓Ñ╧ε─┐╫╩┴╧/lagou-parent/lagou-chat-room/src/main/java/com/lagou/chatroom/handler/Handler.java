package com.lagou.chatroom.handler;

public interface Handler {
}
