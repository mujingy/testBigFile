package com.lagou.chatroom.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class RabbitConfig {


    public static final String RED_PACKET_EXCHANGE = "red_packet_exchange";
    public static final String RED_PACKET_QUEUE = "red_packet_queue";
    public static final String RECORD_ROUTING_KEY = "record_key";

    /**
     * 声明交换机
     */
    @Bean
    public DirectExchange exchange() {
        return new DirectExchange(RED_PACKET_EXCHANGE,
                true, false);
    }

    /**
     * 声明队列
     */
    @Bean
    public Queue queue() {
        return new Queue(RED_PACKET_QUEUE, true, false, false, null);
    }

    /**
     * 绑定
     */
    @Bean
    public Binding binding() {
        return BindingBuilder.bind(this.queue()).to(this.exchange()).with(RECORD_ROUTING_KEY);
    }

    /**
     * 声明RabbitMQ容器工厂
     *
     * @param connectionFactory
     * @return
     */
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        //设置消费者手动ack模式
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        return factory;
    }

    /**
     * 声明RabbitMQ 模板类
     *
     * @param connectionFactory
     * @return
     */
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setConfirmCallback(new RabbitTemplate.ConfirmCallback() {
            @Override
            public void confirm(CorrelationData correlationData, boolean ack, String cause) {
                //ack为true代表发送成功
                if (ack) {
                    log.info("生产者ACK成功:" + correlationData.getId());
                } else {
                    log.error("生产者ACK失败:" + correlationData.getId());
                    //todo
                    //1.获取记录ID
                    //2.开启消息补偿机制
                }
            }
        });
        // 开启return模式-没有路由到指定队列
        rabbitTemplate.setMandatory(true);
        rabbitTemplate.setReturnCallback(new RabbitTemplate.ReturnCallback() {
            @Override
            public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
                log.error("errorMsg", "原因:" + replyCode + " " + replyText + " " + exchange + " " + routingKey);
                //todo 人工预警
            }
        });
        return rabbitTemplate;
    }
}