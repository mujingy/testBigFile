package com.lagou.chatroom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.chatroom.domain.User;

public interface UserMapper extends BaseMapper<User> {
}
