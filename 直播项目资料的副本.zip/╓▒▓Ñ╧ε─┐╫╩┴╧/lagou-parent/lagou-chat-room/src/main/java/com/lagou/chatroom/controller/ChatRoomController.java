package com.lagou.chatroom.controller;

import com.lagou.chatroom.service.RedPacketService;
import com.lagou.common.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/chatroom")
public class ChatRoomController {

    @Autowired
    RedPacketService redPacketService;


    /**
     * 发红包
     *
     * @return
     */
    @PostMapping("/addPacket")
    public ResponseResult addPacket(Long userId, String username, Double amount, Integer num) {
        ResponseResult responseResult = redPacketService.addPacket(userId, username, amount, num);
        return responseResult;
    }

    /**
     * 抢红包
     */
    @PostMapping("/getPacket")
    public ResponseResult getPacket(Long redPacketId, Long userId) {
        ResponseResult responseResult = redPacketService.getRedPacket(redPacketId, userId);
        return responseResult;
    }

    /**
     * 开红包
     */
    @PostMapping("/openRedPacket")
    public ResponseResult openRedPacket(Long redPacketId, Long userId, String username) {
        ResponseResult responseResult = redPacketService.openRedPacket(redPacketId, userId, username);
        return responseResult;
    }


    /**
     * 保持session在线状态
     *
     * @return
     */
    @PostMapping("/keepSession")
    public ResponseResult keepSession() {
        System.out.println("keepSession:");
        return new ResponseResult();
    }
}
