package com.lagou.chatroom.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lagou.chatroom.domain.AccountTransactions;
import com.lagou.chatroom.domain.UserAccount;
import com.lagou.chatroom.mapper.UserAccountMapper;
import com.lagou.chatroom.service.AccountTransactionsService;
import com.lagou.chatroom.service.UserAccountService;
import com.lagou.common.ResponseResult;
import com.lagou.common.StatusCode;
import com.lagou.utils.IdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserAccountServiceImpl extends ServiceImpl<UserAccountMapper, UserAccount>
        implements UserAccountService {

    @Autowired
    AccountTransactionsService accountTransactionsService;

    @Autowired
    IdWorker idWorker;

    /**
     * 账户交易方法
     *
     * @param userId
     * @param amount
     */
    @Override
    public void transaction(Long userId, Double amount, Integer type, String description) {
        //1.根据用户查询对应的账户
        UserAccount userAccount = this.getUserAccountByUserId(userId);
        if (userAccount != null) {
            //2.修改账户额度
            userAccount.setAmount(userAccount.getAmount() + amount);
            this.updateById(userAccount);
            //3.增加账户交易记录
            AccountTransactions accountTransactions = new AccountTransactions();
            accountTransactions.setId(idWorker.nextId());
            accountTransactions.setAccountId(userAccount.getId());
            accountTransactions.setTransactionAmount(amount);
            accountTransactions.setTransactionType(type);
            accountTransactions.setTransactionDescription(description);
            accountTransactions.setTransactionTime(new Date());
            accountTransactionsService.save(accountTransactions);
        }
    }

    /**
     * 检查账户金额
     *
     * @param userId
     * @param amount
     * @return
     */
    @Override
    public ResponseResult checkAmount(Long userId, Double amount) {
        UserAccount userAccount = this.getUserAccountByUserId(userId);
        if (userAccount != null) {
            if (userAccount.getAmount() >= amount) {
                return new ResponseResult(true, StatusCode.OK, "");
            }
        }
        return new ResponseResult(false, StatusCode.ERROR, "账户余额不足!");
    }

    /**
     * 保存账户
     *
     * @param userId
     * @param amount
     * @param status
     * @return
     */
    @Override
    public void addAmount(Long userId, Double amount, Integer status) {
        UserAccount userAccount = new UserAccount();
        userAccount.setId(idWorker.nextId());
        userAccount.setUserId(userId);
        userAccount.setAmount(amount);
        userAccount.setStatus(status);
        this.save(userAccount);
    }


    public UserAccount getUserAccountByUserId(Long userId) {
        //根据用户查询对应的账户
        QueryWrapper<UserAccount> wrapper = new QueryWrapper<UserAccount>();
        wrapper.lambda().eq(UserAccount::getUserId, userId);
        return this.getOne(wrapper);
    }


}
