package com.lagou.chatroom.common;

import org.springframework.context.ApplicationContext;

public class SpringUtil {

    public static ApplicationContext context = null;

}
