package com.lagou.chatroom.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 用户账户信息
 */
@Data
@TableName("t_user_account")
public class UserAccount {
    /**
     * 账户ID
     */
    @TableId
    private Long id;
    /**
     * 账户金额
     */
    @TableField
    private Double amount;

    /**
     * 用户ID
     */
    @TableField
    private Long userId;

    /**
     * 账户状态
     */
    @TableField
    private Integer status;

}
