package com.lagou.chatroom.monitor;

import com.lagou.chatroom.config.RabbitConfig;
import com.lagou.chatroom.domain.RedPacket;
import com.lagou.chatroom.domain.RedPacketRecord;
import com.lagou.chatroom.service.RedPacketRecordService;
import com.lagou.chatroom.service.RedPacketService;
import com.lagou.chatroom.service.UserAccountService;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class RedPacketConsumer {

    @Autowired
    RedPacketRecordService redPacketRecordService;

    @Autowired
    RedPacketService redPacketService;

    @Autowired
    UserAccountService userAccountService;

    @RabbitListener(queues = {RabbitConfig.RED_PACKET_QUEUE})
    public void receive(RedPacketRecord redPacketRecord, Message message, Channel channel) throws IOException {
        try {
            log.info("异步红包记录信息入库:" + redPacketRecord.getRedPacketId());
            //1.个人红包记录入库
            redPacketRecordService.save(redPacketRecord);
            //2.红包剩余金额扣减与红包个数
            RedPacket redPacket = redPacketService.getById(redPacketRecord.getRedPacketId());
            if (redPacket != null) {
                redPacket.setRemainingNum(redPacket.getRemainingNum() - 1);
                redPacket.setRemainingAmount(redPacket.getRemainingAmount() - redPacketRecord.getAmount());
                redPacketService.updateById(redPacket);
            }
            //3.用户对应的账户金额增加
            userAccountService.transaction(redPacketRecord.getUserId(), redPacketRecord.getAmount(),
                    1, "来自群红包");
            //4.MQ 成功ACK   multiple:是否批量确认
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
            log.info("消费者ACK成功:" + redPacketRecord.getRedPacketId());
        } catch (Exception e) {
            log.error("异步红包记录信息入库出错:" + e.getMessage());
            //5.MQ 失败ACK  requeue 是否重回队列
            channel.basicNack(message.getMessageProperties().getDeliveryTag()
                    , false, false);
            log.error("消费者ACK失败:" + redPacketRecord.getRedPacketId());
            //6.开始消息补偿机制
            //todo
        }
    }
}