package com.lagou.chatroom.monitor;

import com.lagou.chatroom.domain.RedPacket;
import com.lagou.chatroom.service.RedPacketService;
import com.lagou.chatroom.service.UserAccountService;
import com.lagou.chatroom.service.impl.RedPacketServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

@Component
public class RedPacketKeyExpirationListener implements MessageListener {

    @Autowired
    RedPacketService redPacketService;

    @Autowired
    UserAccountService userAccountService;

    /**
     * 键过期事件处理
     *
     * @param message
     * @param bytes
     */
    @Override
    public void onMessage(Message message, byte[] bytes) {
        byte[] body = message.getBody();
        byte[] channel = message.getChannel();
        //1.获得过期的key
        String key = new String(body);
        //2.获取事件
        String topic = new String(channel);
        if (key.endsWith(RedPacketServiceImpl.RED_PACKET_KEY)) {
            //3.获取红包ID
            String[] s = key.split("_");
            String redPacketId = s[0];
            //3.1 查询红包
            RedPacket redPacket = redPacketService.getById(redPacketId);
            //3.2 修改账户余额
            userAccountService.transaction(redPacket.getUserId(),
                    redPacket.getRemainingAmount(), 1, "红包已过期!");
        }
    }
}