package com.lagou.chatroom.controller;

import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class IndexController {

    @Value("${chatServer}")
    public String chatServer;

    @RequestMapping("/chat")
    public String index(String serverIP, HttpServletRequest request, ModelMap model) {
        Object user = request.getSession().getAttribute("user");
        Map map = JSON.parseObject(user.toString(), Map.class);
        map.put("id", map.get("id").toString());
        model.addAttribute("user", map);
        model.addAttribute("serverIP", chatServer);
        return "chat";
    }
}
