package com.lagou.chatroom.netty;

import com.google.gson.Gson;
import com.lagou.chatroom.message.CommonMessage;
import com.lagou.chatroom.message.MessageType;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 处理器
 */
public class WebsocketHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

    public static final Map<String, Channel> channelMap = new ConcurrentHashMap<>();

    public static final Map<Object, String> userChannel = new ConcurrentHashMap<>();

    public static final List<Object> userList = Collections.synchronizedList(new ArrayList<>());


    @Override
    protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) throws Exception {
        Channel channel = ctx.channel();
        CommonMessage commonMessage = new Gson().fromJson(msg.text(), CommonMessage.class);
        LinkedHashMap<String, Object> param = new LinkedHashMap<>();
        param.put("id", channel.id().asLongText());
        param.putAll(commonMessage.getParams());
        commonMessage.setParams(param);
        handler(commonMessage, channel);
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        channelMap.putIfAbsent(ctx.channel().id().asLongText(), ctx.channel());
        System.out.println("ChannelId:" + ctx.channel().id().asLongText());
    }


    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        //用户下线移除通道缓存
        if (channelMap.containsKey(ctx.channel().id().asLongText())) {
            channelMap.remove(ctx.channel().id().asLongText());
        }
        System.out.println("用户下线: " + ctx.channel().id().asLongText());
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        //出现异常关闭通道
        ctx.channel().close();
    }

    /**
     * 调用协议方法
     *
     * @param commonMessage
     * @return String
     * @throws Exception
     */
    public void handler(CommonMessage commonMessage, Channel channel) {
        try {
            Map<String, Object> paramsMap = commonMessage.getParams();
            Object[] params = new Object[paramsMap.size()];
            int i = 0;
            for (Entry<String, Object> entry : paramsMap.entrySet()) {
                params[i] = entry.getValue();
                i++;
            }
            Map<String, Channel> channelMap = WebsocketHandler.channelMap;
            //1.判断是否是用户加入房间
            //-101为用户加入房间编号
            if (commonMessage.getCode() == MessageType.User_Join_Room) {
                boolean userIsJoin = false;
                //2.判断自己是否已经在聊天室
                for (Object user : userList) {
                    LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) user;
                    //2.缓存中的user
                    Map userCacheMap = (Map) map.get("data");
                    //3.判断是否在聊天室
                    Map joinUser = (Map) paramsMap.get("data");
                    if (userCacheMap.get("id").equals(joinUser.get("id"))) {
                        //4.存在,则删除用户
                        userList.remove(user);
                        //5.移除用户与通道的关系
                        Channel closeChannel = channelMap.get(userChannel.get(joinUser.get("id")));
                        channelMap.remove(userChannel.get(joinUser.get("id")));
                        closeChannel.close();
                        userIsJoin = true;
                        break;
                    }
                }
                //3.建立user和通道的关系
                Map joinUser = (Map) paramsMap.get("data");
                userChannel.put(joinUser.get("id"), channel.id().asLongText());

                LinkedHashMap<String, Object> map = new LinkedHashMap();
                map.put("data", userList);
                commonMessage.setParams(map);
                //4.将已加入聊天室的用户显示
                for (Entry<String, Channel> entry : channelMap.entrySet()) {
                    String channelId = entry.getKey();
                    if (channelId.equals(channel.id().asLongText())) {
                        entry.getValue().writeAndFlush(new TextWebSocketFrame(new Gson().toJson(commonMessage)));
                    }
                }
                //4.将自己加入用户缓存
                userList.add(paramsMap);
                //5.通知所有用户
                if (!userIsJoin) {
                    List list = new ArrayList();
                    list.add(paramsMap);
                    map.put("data", list);
                    for (Entry<String, Channel> entry : channelMap.entrySet()) {
                        String channelId = entry.getKey();
                        if (!channelId.equals(channel.id().asLongText())) {
                            entry.getValue().writeAndFlush(new TextWebSocketFrame(new Gson().toJson(commonMessage)));
                        }
                    }
                }
            } else if (commonMessage.getCode() == MessageType.User_Leave_Room) {//-102为用户离开房间编号
                //1.将自己移除用户缓存
                for (Object user : userList) {
                    LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) user;
                    //2.缓存中的user
                    Map userCacheMap = (Map) map.get("data");
                    //3.移除自己
                    Map closeUser = (Map) paramsMap.get("data");
                    if (userCacheMap.get("id").equals(closeUser.get("id"))) {
                        userList.remove(user);
                        //5.移除用户与通道的关系
                        channelMap.remove(userChannel.get(closeUser.get("id")));
                        break;
                    }
                }
                LinkedHashMap<String, Object> map = new LinkedHashMap();
                //4.通知所有用户
                List list = new ArrayList();
                list.add(paramsMap);
                map.put("data", list);
                for (Entry<String, Channel> entry : channelMap.entrySet()) {
                    String channelId = entry.getKey();
                    if (!channelId.equals(channel.id().asLongText())) {
                        entry.getValue().writeAndFlush(new TextWebSocketFrame(new Gson().toJson(commonMessage)));
                    }
                }
            } else {
                for (Entry<String, Channel> entry : channelMap.entrySet()) {
                    String channelId = entry.getKey();
                    if (!channelId.equals(channel.id().asLongText())) {
                        entry.getValue().writeAndFlush(new TextWebSocketFrame(new Gson().toJson(commonMessage)));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
