$(function () {
    //创建定时器15分钟触发一次.保持session活跃
    var time = setInterval(function () {
        //保持session 20分钟发送一次
        $.ajax({
            url: "/chatroom/keepSession",
            type: "POST",
            success: function (data) {
            }
        });
    }, 1000 * 60 * 20);


    var ws = new WebSocket("ws://" + serverIP + ":9875/ws");
    ws.onopen = function () {
        console.log("连接成功:" + user.username);
        var params = new Object();
        params.data = user;
        send(protocol.userJoinRoom.code, params);
    };
    ws.onmessage = function (evt) {
        var data = JSON.parse(evt.data);
        for (var i in protocol) {
            if (protocol[i].code == data.code) {
                protocol[i].handler(data);
            }
        }
    };
    ws.onclose = function (evt) {
        console.log("WebSocketClosed!");
    };
    //监听浏览器关闭事件
    window.onbeforeunload = function () {
        console.log('关闭操作');
        var params = new Object();
        params.data = user;
        send(protocol.userLeaveRoom.code, params);
    };
    ws.onerror = function (evt) {
        console.log("WebSocketError!");
    };

    /** 发送消息 */
    function send(code, params) {
        var obj = new Object();
        obj.code = code;
        obj.params = params;
        var json = JSON.stringify(obj);
        ws.send(json);
    }

    /** 协议封装 */
    function protocolHandler(code, handler) {
        var obj = {
            code: code,
            handler: handler
        }
        return obj;
    }

    var joinRoom = function (data) {
        $("#first").hide();
        $("#second").hide();
        $("#room").show();
        $("#roomCode").text(data.params.code);
    }

    var protocol = new Object();
//登录返回
    protocol.login = protocolHandler(100, function (data) {
        $("#first").hide();
        $("#second").show();
        $("#room").hide();
        $("#username").text(data.params.name);
        $("#user").text(data.params.name);
    })
//发送消息到所有
    protocol.msgAll = protocolHandler(102, function (data) {
        if (data.params.msgType == "send_red_packet") {
            $("#msg_list").append(`<li class="active"}>
                                  <div class="main" style="align-items: center">
                                        <img class="avatar" width="30" height="30" src="/img/user.png" style="margin-top: 0">
                                        <div>
                                            <div class="user_name">${data.params.username}</div>
                                            <div class="pager_container" id="${data.params.data}">
                                                 <div class="mask"></div>
                                                 <img src="/img/pager.png" alt="" class='pager_png'>
                                            </div>
                                        </div>
                                  </div>
                              </li>`);
            // 置底
            setBottom();
        } else {
            $("#msg_list").append(`<li class="active"}>
                                  <div class="main">
                                    <img class="avatar" width="30" height="30" src="/img/user.png">
                                    <div>
                                        <div class="user_name">${data.params.username}</div>
                                        <div class="text">${data.params.msg}</div>
                                    </div>                       
                                   </div>
                              </li>`);
            // 置底
            setBottom();
        }

    })

//加入房间
    protocol.joinRoomById = protocolHandler(104, joinRoom);
    protocol.joinRoomRandom = protocolHandler(105, joinRoom);
    protocol.createRoom = protocolHandler(106, joinRoom);
//离开房间
    protocol.leaveRoom = protocolHandler(107, function (data) {
        $("#first").hide();
        $("#second").show();
        $("#room").hide();
        $("#allTable").empty();
    })
//用户加入
    protocol.userJoinRoom = protocolHandler(-101, function (data) {
        $(data.params.data).each(function (index, element) {
            var userJoin = ` <li id="${element.data.id}">
                        <img class="avatar" width="30" height="30"  src="/img/user.png">
                        <p class="name">${element.data.username}</p>
                      </li>`
            $('#user_list').append(userJoin);
        })
    })
//用户离开
    protocol.userLeaveRoom = protocolHandler(-102, function (data) {
        $('#' + data.params.data.id).remove();
    })
//服务器主动推送
    protocol.serverPush = protocolHandler(-200, function (data) {

    })
//错误信息
    protocol.errorMsg = protocolHandler(-400, function (data) {
        layer.msg(data.msg);
    })


    // 用户列表
    let user_str = ''
    //  消息框
    let msg_str = ''


    $('#msg_list').empty();

    $('#my_test').bind({
        focus: function (event) {
            event.stopPropagation()
            $('#my_test').val('');
            $('.arrow_box').hide()
        },
        keydown: function (event) {
            event.stopPropagation()
            if (event.keyCode === 13) {
                if ($('#my_test').val().trim() === '') {
                    this.blur()
                    $('.arrow_box').show()
                    setTimeout(() => {
                        this.focus()
                    }, 1000)
                } else {
                    $('.arrow_box').hide()
                    //发送消息
                    sendMsg();
                    this.blur()
                    setTimeout(() => {
                        this.focus()
                    })
                }
            }
        }
    });
    $('#send').on('click', function (event) {
        event.stopPropagation()
        if ($('#my_test').val().trim() === '') {
            $('.arrow_box').show()
        } else {
            sendMsg();
        }
    })

    function sendMsg() {
        //发送消息
        var params = new Object();
        params.msg = $("#my_test").val();
        params.username = user.username;
        send(protocol.msgAll.code, params);
        $("#msg_list").append(`<li class="active"}>
                                  <div class="main self">
                                      <div class="text">` + params.msg + `</div>
                                      <img class="avatar" width="30" height="30" src="/img/my.png">
                                  </div>
                              </li>`);
        $("#my_test").val('');
        // 置底
        setBottom();
    }

    // 置底
    function setBottom() {
        // 发送消息后滚动到底部
        const container = $('.m-message')
        const scroll = $('#msg_list')
        container.animate({
            scrollTop: scroll[0].scrollHeight - container[0].clientHeight + container.scrollTop() + 100
        });
    }

    // 红包
    $('#pager_icon').on('click', function (e) {
        $('#pager_moeny').val('')
        $('#pager_mount').val('')
        $('#pager_des').val('')
        e.stopPropagation()
        $('.m-pager').show()
    })
    $('.m-pager').on('click', function (e) {
        if (e.target.className === 'm-pager') {
            $('.m-pager').hide()
            $('#pager_moeny').val('')
            $('#pager_mount').val('')
            $('.total_money').text('0.00')
        }
    })
    $('.sidebar').on('click', function (e) {
        $('.m-pager').hide()
    })
    const reg = /^[0-9]+.?[0-9]*$/

    $('#pager_moeny').bind({
        input: function (e) {
            if (!reg.test(e.currentTarget.value)) {
                e.currentTarget.value = e.currentTarget.value.replace(/[^\d.]/g, "")
            } else {
                if (e.currentTarget.value === '') {
                    $('.total_money').text('0.00')
                } else {
                    e.currentTarget.value = e.currentTarget.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
                    if (e.currentTarget.value.indexOf('.') === -1) {
                        // 不包含小数点
                        let str = e.currentTarget.value + '.00'
                        $('.total_money').text(str)
                    } else {
                        // 包含小数点
                        // 小数点后没有数字
                        if (e.currentTarget.value.split('.')[1].length === 0) {
                            let str = e.currentTarget.value + '00'
                            $('.total_money').text(str)
                        } else if (e.currentTarget.value.split('.')[1].length === 1) { // 小数点后只有一位数字
                            let str = e.currentTarget.value + '0'
                            $('.total_money').text(str)
                        } else {
                            $('.total_money').text(e.currentTarget.value)
                        }
                    }
                    if ($('#pager_mount').val() != '') {

                        $(".send_pager").removeAttr('disabled');
                    }
                }
            }
        }
    })
    $('#pager_mount').bind({
        input: function (e) {
            if (e.currentTarget.value.length == 1) {
                e.currentTarget.value = e.currentTarget.value.replace(/[^1-9]/g, '')
            } else {
                e.currentTarget.value = e.currentTarget.value.replace(/\D/g, '')
            }
            if ($('#pager_moeny').val() != '') {

                $(".send_pager").removeAttr('disabled');
            }
        }
    })
    let pager_mount, pager_moeny, pager_des = ''
    // 塞进红钱包
    $('.send_pager').on('click', function () {
        $('.m-pager').hide()
        pager_mount = $('#pager_mount').val()
        pager_moeny = $('#pager_moeny').val()
        pager_des = $('#pager_des').val()
        $('#pager_moeny').val('')
        $('#pager_mount').val('')
        $('#pager_des').val('')
        //发红包
        $.ajax({
            url: "/chatroom/addPacket?userId=" + user.id + "&username=" + user.username + "&amount=" + pager_moeny + "&num=" + pager_mount,
            type: "POST",
            success: function (data) {
                if (data.code == 20000) {
                    // 添加自己的对话
                    $("#msg_list").append(`<li class="active">
                                  <div class="main self">
                                    <div class="pager_container" id="${data.data}">
                                        <div class="mask"></div>
                                        <img src="/img/pager.png" alt="" class='pager_png'>
                                    </div>
                                    <img class="avatar" width="30" height="30" src="/img/my.png">   
                                  </div>
                              </li>`);

                    var params = new Object();
                    params.msgType = "send_red_packet";
                    params.data = data.data;
                    params.username = user.username;
                    send(protocol.msgAll.code, params);
                    // 置底
                    setBottom();
                    //添加发送按钮禁用
                    $('.send_pager').attr('disabled', "true");
                    //将金额变成初始金额
                    $('.total_money').text("0.00");
                } else {
                    alert(data.message)
                }

            }
        });
    })

    var redPacketId;
    var redPacket;
    // 点击红包
    $('#msg_list').delegate('.pager_container', 'click', function (e) {
        //1.获取红包ID
        redPacketId = e.currentTarget.id;
        //2.查询红包
        $.ajax({
            url: "/chatroom/getPacket?redPacketId=" + redPacketId + "&userId=" + user.id,
            type: "POST",
            success: function (data) {
                if (data.code == 20000) {
                    redPacket = data.data;
                    $('.redPacketName').text(redPacket.username)
                    $('.get_pager').show()
                } else {
                    var arr = data.data;
                    $('.get_pager').hide()
                    $('.pager_result').show()
                    var money = 0;
                    var msgs = data.message.split("|");
                    $('.redPacketName').text(msgs[3])
                    $('#pager_result_money').text(msgs[0]);
                    $('.receive_list ul').empty();
                    $.each(arr, function (i, j) {
                        money = (money + j.amount).toFixed(2) * 100 / 100;
                        $('.receive_list ul').append("<li>\n" +
                            "                                    <img src=\"/img/hongbao.png\" alt=\"\">\n" +
                            "                                    <div>\n" +
                            "                                        <p class=\"flex_between\"><span>" + j.username + "</span><span id=\"receive_money\">" + j.amount + "元</span></p>\n" +
                            "                                        <p id=\"receive_time\">" + dateFormat("YYYY-mm-dd HH:MM", new Date(j.createTime)) + "</p>\n" +
                            "                                    </div>\n" +
                            "                                </li>")
                    })
                    $('#already_receive_top').text('已领取' + arr.length + '/' + msgs[2] + '个，共' + money + '/' + msgs[1] + '元')
                }
            }
        });

    })
    // 点击开
    $('.open_pager').on('click', function (e) {
        //开红包
        $.ajax({
            url: "/chatroom/openRedPacket?redPacketId=" + redPacketId +
                "&userId=" + user.id + "&username=" + user.username,
            type: "POST",
            success: function (data) {
                if (data.code == 20000) {
                    var arr = data.data;
                    var end = arr[arr.length - 1];
                    $('.get_pager').hide()
                    $('.pager_result').show()
                    var money = 0;
                    $('#pager_result_money').text(end.amount + "元")
                    $('.receive_list ul').empty();
                    $.each(arr, function (i, j) {
                        money = (money + j.amount).toFixed(2) * 100 / 100;
                        $('.receive_list ul').append("<li>\n" +
                            "                                    <img src=\"/img/hongbao.png\" alt=\"\">\n" +
                            "                                    <div>\n" +
                            "                                        <p class=\"flex_between\"><span>" + j.username + "</span><span id=\"receive_money\">" + j.amount + "元</span></p>\n" +
                            "                                        <p id=\"receive_time\">" + dateFormat("YYYY-mm-dd HH:MM", new Date(j.createTime)) + "</p>\n" +
                            "                                    </div>\n" +
                            "                                </li>")
                    })
                    $('#already_receive_top').text('已领取' + arr.length + '/' + redPacket.num + '个，共' + money + '/' + redPacket.amount + '元');
                    $('#' + redPacketId).find(".mask").show()
                } else {
                    var arr = data.data;
                    $('.get_pager').hide()
                    $('.pager_result').show()
                    var money = 0;
                    $('.redPacketName').text(redPacket.username)
                    $('#pager_result_money').text(data.message);
                    $('.receive_list ul').empty();
                    $.each(arr, function (i, j) {
                        money = (money + j.amount).toFixed(2) * 100 / 100;
                        $('.receive_list ul').append("<li>\n" +
                            "                                    <img src=\"/img/hongbao.png\" alt=\"\">\n" +
                            "                                    <div>\n" +
                            "                                        <p class=\"flex_between\"><span>" + j.username + "</span><span id=\"receive_money\">" + j.amount + "元</span></p>\n" +
                            "                                        <p id=\"receive_time\">" + dateFormat("YYYY-mm-dd HH:MM", new Date(j.createTime)) + "</p>\n" +
                            "                                    </div>\n" +
                            "                                </li>")
                    })
                    $('#already_receive_top').text('已领取' + arr.length + '/' + redPacket.num + '个，共' + money + '/' + redPacket.amount + '元')
                    $('#' + redPacketId).find(".mask").show();
                }
            }
        });

    })
    // 点击红包结果空白区域
    $('.pager_result').on('click', function (e) {
        if (e.target.className === 'pager_result') {
            $('.pager_result').hide()
        }
    })
    // 关闭抢红包
    $('#get_pager .close img').click(function (e) {
        $('.get_pager').hide()
    })

    //  格式化时间
    function dateFormat(fmt, date) {
        let ret;
        const opt = {
            "Y+": date.getFullYear().toString(),        // 年
            "m+": (date.getMonth() + 1).toString(),     // 月
            "d+": date.getDate().toString(),            // 日
            "H+": date.getHours().toString(),           // 时
            "M+": date.getMinutes().toString(),         // 分
            "S+": date.getSeconds().toString()          // 秒
        };
        for (let k in opt) {
            ret = new RegExp("(" + k + ")").exec(fmt);
            if (ret) {
                fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
            }
            ;
        }
        ;
        return fmt;
    }
});