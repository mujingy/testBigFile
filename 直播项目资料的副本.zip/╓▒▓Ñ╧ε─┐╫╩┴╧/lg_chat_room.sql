/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50728
 Source Host           : localhost:3306
 Source Schema         : lg_chat_room

 Target Server Type    : MySQL
 Target Server Version : 50728
 File Encoding         : 65001

 Date: 13/01/2021 10:03:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_account_transactions
-- ----------------------------
DROP TABLE IF EXISTS `t_account_transactions`;
CREATE TABLE `t_account_transactions`  (
  `id` bigint(20) NOT NULL COMMENT '记录ID',
  `account_id` bigint(20) NULL DEFAULT NULL COMMENT '账户ID',
  `transaction_amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '交易金额',
  `transaction_type` int(11) NULL DEFAULT NULL COMMENT '交易类型',
  `transaction_description` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '交易描述',
  `transaction_time` datetime(0) NULL DEFAULT NULL COMMENT '交易时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for t_red_packet
-- ----------------------------
DROP TABLE IF EXISTS `t_red_packet`;
CREATE TABLE `t_red_packet`  (
  `id` bigint(20) NOT NULL COMMENT '红包ID',
  `amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '红包金额',
  `num` int(11) NULL DEFAULT NULL COMMENT '红包个数',
  `remaining_amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '剩余金额',
  `remaining_num` int(11) NULL DEFAULT NULL COMMENT '剩余红包个数',
  `user_id` bigint(11) NULL DEFAULT NULL COMMENT '用户ID',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '用户姓名',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for t_red_packet_record
-- ----------------------------
DROP TABLE IF EXISTS `t_red_packet_record`;
CREATE TABLE `t_red_packet_record`  (
  `id` bigint(20) NOT NULL COMMENT '红包记录ID',
  `amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '红包金额',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户ID',
  `red_packet_id` bigint(20) NULL DEFAULT NULL COMMENT '红包ID',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `id` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '用户名',
  `nickname` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '昵称',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '密码',
  `created_date` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for t_user_account
-- ----------------------------
DROP TABLE IF EXISTS `t_user_account`;
CREATE TABLE `t_user_account`  (
  `id` bigint(20) NOT NULL COMMENT '账户ID',
  `amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '账户金额',
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户ID',
  `status` int(255) NULL DEFAULT NULL COMMENT '账户状态0-异常 1-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
